import React, { Component } from 'react'

class Messages extends Component {

  render() {
    return (
      <div>
        <h2>Messages</h2>
      </div>
    )
  }

}

module.exports = Messages
